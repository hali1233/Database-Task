-- MySQL dump 10.13  Distrib 8.0.29, for macos12 (x86_64)
--
-- Host: localhost    Database: task
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Content`
--

DROP TABLE IF EXISTS `Content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Content` (
  `question_id` int NOT NULL AUTO_INCREMENT,
  `question` text,
  `answer_A` text,
  `answer_B` text,
  `answer_C` text,
  `answer_D` text,
  `correct_answer` char(1) DEFAULT NULL,
  `image` longblob,
  `answered_by_username` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Content`
--

LOCK TABLES `Content` WRITE;
/*!40000 ALTER TABLE `Content` DISABLE KEYS */;
INSERT INTO `Content` VALUES (1,'What is the color of the sky in the image? A. Red, B. Blue, C. Green, D. Orange','Red','Blue','Green','Orange','B',_binary '<binary_image_data>','user1'),(2,'What is the color of the sky in the image? A. Red, B. Blue, C. Green, D. Orange','Red','Blue','Green','Orange','B',_binary '<binary_image_data>','user1'),(3,'What is the color of the sky in the image? A. Red, B. Blue, C. Green, D. Orange','Red','Blue','Green','Orange','B',NULL,'user1');
/*!40000 ALTER TABLE `Content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NetworkInfo`
--

DROP TABLE IF EXISTS `NetworkInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NetworkInfo` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(4) DEFAULT NULL,
  `network_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NetworkInfo`
--

LOCK TABLES `NetworkInfo` WRITE;
/*!40000 ALTER TABLE `NetworkInfo` DISABLE KEYS */;
INSERT INTO `NetworkInfo` VALUES (1,'5G65','Library_Network_5G'),(2,'4F6I','Library_Network_4G'),(3,'9D21','Library_Network_3G'),(4,'6H78','Library_Network_2G'),(5,'5G65','Library_Network_5G'),(6,'4F6I','Library_Network_4G'),(7,'9D22','Library_Network_3G'),(8,'6H73','Library_Network_2G'),(9,'5G64','Library_Network_5G'),(10,'4F65','Library_Network_4G'),(11,'9D26','Library_Network_3G'),(12,'6H77','Library_Network_2G'),(13,'5G68','Library_Network_5G'),(14,'4F69','Library_Network_4G'),(15,'9D10','Library_Network_3G'),(16,'6H11','Library_Network_2G'),(17,'5G65','Library_Network_5G'),(18,'4F6I','Library_Network_4G'),(19,'9D22','Library_Network_3G'),(20,'6H73','Library_Network_2G'),(21,'5G64','Library_Network_5G'),(22,'4F65','Library_Network_4G'),(23,'9D26','Library_Network_3G'),(24,'6H77','Library_Network_2G'),(25,'5G68','Library_Network_5G'),(26,'4F69','Library_Network_4G'),(27,'9D10','Library_Network_3G'),(28,'6H11','Library_Network_2G');
/*!40000 ALTER TABLE `NetworkInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Users` (
  `username` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `three_digit_number` int DEFAULT NULL,
  `wins` int DEFAULT NULL,
  `losses` int DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,'David','Warner',789,2,1),(2,'John','Doe',123,5,2),(3,'Charlas','Cris',987,4,1),(4,'Jane','Smith',456,3,1),(5,'David','Warner',789,2,1),(6,'John','Doe',123,5,2),(7,'Charlas','Cris',987,4,1),(8,'Jane','Smith',456,3,1),(9,'David','Warner',700,2,1),(10,'John','Doe',313,5,2),(11,'Charlas','Cris',100,5,1),(12,'Jane','Smith',456,3,0),(13,'David','Warner',789,1,1),(14,'John','Doe',123,5,0),(15,'Charlas','Cris',987,4,5),(16,'Jane','Smith',456,3,3),(17,'David','Warner',789,2,1),(18,'John','Doe',123,5,2),(19,'Charlas','Cris',987,4,1),(20,'Jane','Smith',456,3,1),(21,'David','Warner',700,2,1),(22,'John','Doe',313,5,2),(23,'Charlas','Cris',100,5,1),(24,'Jane','Smith',456,3,0),(25,'David','Warner',789,1,1),(26,'John','Doe',123,5,0),(27,'Charlas','Cris',987,4,5),(28,'Jane','Smith',456,3,3);
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-07 21:41:22
